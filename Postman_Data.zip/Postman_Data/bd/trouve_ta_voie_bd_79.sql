-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 09, 2022 at 07:06 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trouve_ta_voie_bd_79`
--

-- --------------------------------------------------------

--
-- Table structure for table `grimpes`
--

DROP TABLE IF EXISTS `grimpes`;
CREATE TABLE IF NOT EXISTS `grimpes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(50) NOT NULL,
  `style` enum('Traditionnelle','Sportive','Moulinette') NOT NULL,
  `description` varchar(500) NOT NULL,
  `difficulte` int(11) NOT NULL,
  `nbEtoiles` decimal(10,2) DEFAULT 1.00,
  `nbVotes` int(11) DEFAULT 0,
  `utilisateurId` int(11) DEFAULT NULL,
  `lieuxId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `utilisateurId` (`utilisateurId`),
  KEY `lieuxId` (`lieuxId`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `grimpes`
--

INSERT INTO `grimpes` (`id`, `titre`, `style`, `description`, `difficulte`, `nbEtoiles`, `nbVotes`, `utilisateurId`, `lieuxId`) VALUES
(1, 'Exceptional granite, but tricky to climb', 'Sportive', 'L\'histoire d\'amour entre les grimpeurs et Yosemite n\'est bien sûr pas sans raison. Les grimpeurs adorent le rock, et Yosemite offre une mer de granit incroyable, avec une nature à couper le souffle. La Mecque de l\'escalade en Californie est fabriquée à partir du meilleur granit que vous trouverez jamais. Le seul problème est qu\'il est sacrément difficile de monter dessus. Soyez prêt à affronter des prises de pied microscopiques et des parois rocheuses lisses interrompues par des fissures.', 9, '2.30', 11, 1, 1),
(2, 'Yosemite’s world-famous routes', 'Traditionnelle', 'Plus connu pour ses immenses murs de granit, le bloc de Yosemite est à égalité avec les meilleurs au monde. Midnight Lightning (V8), l\'emblème du Camp 4, est sans doute le problème de bloc le plus célèbre au monde. Yosemite accueille de nombreuses autres ascensions de renommée mondiale. Le Dawn Wall, avec la note puissante de 5.14d, est la plus difficile des ascensions de grands murs. El Capitan - à 3000 pieds de haut - est l\'un des meilleurs candidats pour l\'escalade', 14, '2.00', 7, 2, 1),
(3, 'Tre Cime, Cinque Torri and Marmolada South Face', 'Traditionnelle', 'Les Dolomites, qui s\'étendent sur 80 km à l\'est de Bolzano, contiennent de nombreuses flèches rocheuses impressionnantes, certaines ressemblant à celles que vous trouverez lors des expéditions d\'escalade de Tantalus Range, dépassant souvent plus de 9 000 pieds. Mon préféré est Tre Cime. Les trois murs de 1500 pieds sont garantis pour vous faire tomber la mâchoire, en particulier les grands toits de Cima Ovest, qui abritent plusieurs pièces d\'essai 5.14b. Grimper au sommet', 6, '1.00', 0, 6, 3),
(4, 'Le tracé', 'Traditionnelle', 'Il y a les sentiers qui vont de A à B, ce sont des sentiers dits linéaires, puisqu’ils ont la forme d’une ligne. Certains sites s’occupent de déplacer votre véhicule du stationnement A vers le stationnement B moyennant certains frais. Il est aussi possible de revenir sur vos pas et donc de faire A->B et B->A, cependant, il faudra doubler la durée de la randonnée, ce qui peut rendre l’aventure un peu plus périlleuse.', 7, '1.30', 7, 6, 3),
(5, 'Sentier international des Appalaches (SIA)', 'Traditionnelle', 'Le SIA est un sentier qui parcourt presque l’entièreté de la Gaspésie. Il est possible de le faire par segments (voir la section « Sous-sentiers SIA ») ou dans sa totalité. Il demande une longue préparation puisque vous allez devoir gérer vos ravitaillements en nourriture, mais aussi, vous risquez d’avoir besoin d’aide pour gérer un bris d’équipement.', 6, '3.70', 7, 6, 3),
(6, 'Le Sentier de l’Estrie', 'Sportive', 'A-Z, 200km, 14 jours, Difficile, Camping & Refuges Le sentier parcourt l’Estrie dans l’axe nord-sud, il passe entre autres par les monts Sutton et le mont Orford. Il offre la possibilité de le faire par segments, mais on doit impérativement être inscrit comme membre pour pouvoir y accéder. Il demande une bonne préparation puisqu’il faut gérer ses ravitaillements en nourriture.', 9, '2.40', 5, 6, 3),
(7, 'Sentiers frontaliers, Estrie', 'Moulinette', 'Comme son nom l’indique, il longe la frontière Canada/États-Unis. Quelquefois, vous vous retrouvez même à marcher dessus! Et sans blague, vous devez avoir votre passeport avec vous au cas où vous rencontriez des agents des services frontaliers. Ce sentier peut sembler facile, mais au contraire, certaines parties sont assez escarpées, il n’est pas à prendre à la légère.', 13, '3.00', 7, 2, 3),
(8, 'La traversée de Charlevoix', 'Moulinette', 'Les Dolomites, qui s\'étendent sur 80 km à l\'est de Bolzano, contiennent de nombreuses flèches rocheuses impressionnantes, certaines ressemblant à celles que vous trouverez lors des expéditions d\'escalade de Tantalus Range, dépassant souvent plus de 9 000 pieds.', 11, '3.00', 5, 1, 3),
(9, 'Les monts Groulx, Côte-Nord', 'Sportive', 'Ce sentier, près de Manicouagan, n’est pas à sous-estimer ; plusieurs l’ont appris à leurs dépens. Il est recommandé aux randonneurs expérimentés et son éloignement nécessite des mesures de sécurité supplémentaires. Les Dolomites, qui s\'étendent sur 80 km à l\'est de Bolzano, contiennent de nombreuses flèches rocheuses impressionnantes, certaines ressemblant à celles que vous trouverez lors des expéditions d\'escalade de Tantalus Range, dépassant souvent plus de 9 000 pieds.', 14, '1.00', 0, 6, 4),
(10, 'Zen Nature, Lanaudière', 'Traditionnelle', 'Les Dolomites, qui s\'étendent sur 80 km à l\'est de Bolzano, contiennent de nombreuses . Cette boucle offre un sentier intermédiaire, mais accessible à tous. Elle offre des facilité comme le transport de bagages d’un site à l’autre et la possibilité de dormir à l’auberge. De cette façon, vous pouvez vous initier à la longue randonnée tout en voyageant légèrement. Évidemment, si vous souhaitez vivre l’expérience pleinement, vous pouvez tout transporter avec vous et dormir dans votre tente.', 7, '5.00', 25, 6, 4),
(11, 'Parc linéaire interprovincial Petit Témis', 'Sportive', 'Ce sentier linéaire qui chevauche le Nouveau-Brunswick et le Québec permet d’y faire une randonnée sur un sentier assez dégagé puisqu’il est partagé avec les vélos. Tout au long de ce sentier, vous trouverez des abris avec quelques services et des sites de camping. Vous pourrez aussi vous arrêter dans des villages tels que Saint-Louis-du-Ha! Ha! ou Dégelis pour faire le plein de provisions ou pour y passer la nuit.', 8, '3.00', 2, 1, 4),
(12, 'Vallée Bras-du-Nord, Capitale-Nationale', 'Sportive', 'Ce sentier est géré par la Vallée Bras-du-Nord Coop de solidarité.  Malgré que ce sentier soit assez court et qu’il se fasse en refuges, on vous demande d’avoir une certaine expérience avant de l’entreprendre.', 8, '3.10', 7, 2, 4),
(13, 'Vallée Bras-du-Nord, Capitale-Nationale', 'Moulinette', 'Ce sentier est géré par la Vallée Bras-du-Nord Coop de solidarité.  Malgré que ce sentier soit assez court et qu’il se fasse en refuges, on vous demande d’avoir une certaine expérience avant de l’entreprendre. Ce sentier est géré par la Vallée Bras-du-Nord Coop de solidarité et on y trouve les mêmes restrictions que pour le Sentier Bras-du-Nord.', 15, '4.80', 28, 2, 2),
(14, 'Sentier National du Bas-Saint-Laurent', 'Traditionnelle', 'Ce sentier, qui traverse le parc national du Lac-Témiscouata et longe le fleuve Saint-Laurent, offre une variété de paysages intéressants. Il est possible d’y dormir parfois en refuges ou en camping, mais comme vous allez croiser quelques villes et villages, vous pouvez aussi vous arrêter dans quelques auberges. Vous pourrez par la même occasion en profiter pour refaire le plein de provisions.', 7, '4.00', 27, 2, 2),
(15, 'Sentier des Caps, Charlevoix', 'Sportive', '-B, 50km, 3 jours, Difficile, Camping & Refuges Le Sentier des Caps est très populaire pour la raquette l’hiver, mais il est aussi agréable de le faire en été. Il est possible de le faire en trois jours, mais vous pouvez allonger le plaisir en vous arrêtant à chaque refuge ou camping et le faire en 6 jours. Plusieurs refuges offrent des points de vue exceptionnels sur le fleuve ainsi que des levers de soleil à couper le souffle.', 12, '4.70', 36, 1, 2),
(16, 'Sentier Inter-Centre, Laurentides', 'Traditionnelle', 'Ce sentier est très prisé en hiver pour le ski de fond, mais il peut être très intéressant à faire en été. Les refuges sont judicieusement placés près de magnifiques lacs ou de très beaux points de vue. Si vous désirez visiter tous les refuges, vous pourriez avoir la chance de le faire en 5 jours.', 8, '3.30', 3, 4, 7),
(17, 'Traversée de la Mauricie', 'Sportive', 'La traversée de la Mauricie n’est pas à prendre à la légère, vous aurez près de 3000m de dénivelé vertical à franchir.', 13, '4.70', 45, 4, 7),
(18, 'Vianney-Guillemette / Chute du Diable', 'Moulinette', 'Ce sentier est très prisé en hiver pour le ski de fond, mais il peut être très intéressant à faire en été. Les refuges sont judicieusement placés près de magnifiques lacs ou de très beaux points de vue. Si vous désirez visiter tous les refuges, vous pourriez avoir la chance de le faire en 5 jours.', 12, '3.00', 4, 1, 7),
(19, 'Parcours Chic-Chocs', 'Sportive', 'Vous trouverez le sentier en question sur la carte de « l’Arrière-pays« . Il y a peu d’informations disponibles et malgré une dizaine d’appels et de courriels, nous avons été incapables de parler à un responsable du parc.', 14, '2.60', 5, 1, 7),
(20, 'Estrie, Boucle Franceville et Trois Sommets', 'Moulinette', 'Il n’existe pas d’itinéraire prédéfini ; la distance et le nombre de jours ont été calculés approximativement. Ici, nous avons simulé un itinéraire que nous avons nommé « Le renard » et qui parcourt l’ensemble du parc en quatre jours.', 7, '2.40', 10, 2, 8),
(21, 'Parc régional du lac Kénogami', 'Sportive', 'Ce sentier linéaire compte quatre sites de camping et trois refuges, ainsi vous pouvez parcourir ce sentier à votre vitesse. En plus d’y trouver plusieurs points de vue, ce sentier possède un pont suspendu au-dessus de la rivière Cyriac et une nacelle autotractée d’une centaine de mètres pour traverser la rivière Pikauba.', 14, '4.20', 16, 2, 8),
(22, 'Les sentiers du SIA', 'Traditionnelle', 'Il s’agit de segments qui composent le sentier international des Appalaches. Le SIA est tellement long que ces parties constituent de longues randonnées en elles-mêmes. Il est possible de les parcourir sans s’engager pour la totalité du sentier du SIA. Ils se trouvent en Gaspésie.', 9, '4.70', 45, 4, 5),
(23, 'Parc national du Canada Forillon', 'Moulinette', '-A, 65km, 4 jours, Intermédiaire, Camping & Refuges. Cette boucle offre un sentier intermédiaire, mais accessible à tous. Elle offre des facilité comme le transport de bagages d’un site à l’autre et la possibilité de dormir à l’auberge. De cette façon, vous pouvez vous initier à la longue randonnée tout en voyageant légèrement. Évidemment, si vous souhaitez vivre l’expérience pleinement, vous pouvez tout transporter avec vous et dormir dans votre tente.', 12, '4.80', 46, 1, 5),
(24, 'Haute-Gaspésie', 'Moulinette', 'A-Z, 200km, 14 jours, Difficile, Camping & Refuges. Le sentier parcourt l’Estrie dans l’axe nord-sud, il passe entre autres par les monts Sutton et le mont Orford. Il offre la possibilité de le faire par segments, mais on doit impérativement être inscrit comme membre pour pouvoir y accéder. Il demande une bonne préparation puisqu’il faut gérer ses ravitaillements en nourriture.', 10, '4.70', 36, 2, 5),
(25, 'Côte-de-Gaspé', 'Sportive', 'Ce sentier est géré par la Vallée Bras-du-Nord Coop de solidarité.  Malgré que ce sentier soit assez court et qu’il se fasse en refuges, on vous demande d’avoir une certaine expérience avant de l’entreprendre.', 7, '3.20', 12, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) DEFAULT NULL,
  `path` varchar(255) NOT NULL,
  `grimpeId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `grimpeId` (`grimpeId`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `nom`, `path`, `grimpeId`) VALUES
(1, '08750c1f-3894-4cc6-ba72-7df314d05beb.jpg', '/img/grimpe/08750c1f-3894-4cc6-ba72-7df314d05beb.jpg', 1),
(2, '58a50d66-7998-4972-ab2b-7bfae5f48125.jpg', '/img/grimpe/58a50d66-7998-4972-ab2b-7bfae5f48125.jpg', 1),
(3, 'c0a5f404-54a9-4830-929f-6d6761e4a4e7.jpg', '/img/grimpe/c0a5f404-54a9-4830-929f-6d6761e4a4e7.jpg', 2),
(4, 'bfdd2428-22a7-49af-b605-d301ef47fc74.jpg', '/img/grimpe/bfdd2428-22a7-49af-b605-d301ef47fc74.jpg', 2),
(5, '19c77dd5-57d8-486c-bb67-548940b9ce0e.jpg', '/img/grimpe/19c77dd5-57d8-486c-bb67-548940b9ce0e.jpg', 2),
(6, 'a64a1289-70ea-4f27-a40c-d75116fa9799.jpg', '/img/grimpe/a64a1289-70ea-4f27-a40c-d75116fa9799.jpg', 3),
(7, '49e27191-c19d-4045-a97c-f88fba6af93e.jpg', '/img/grimpe/49e27191-c19d-4045-a97c-f88fba6af93e.jpg', 3),
(8, '6e537cdd-5f0a-48b0-82f8-cb3b72d8fcab.jpg', '/img/grimpe/6e537cdd-5f0a-48b0-82f8-cb3b72d8fcab.jpg', 4),
(9, 'fb03fc3a-51a6-4587-a0f7-f81ec901a1e9.jpg', '/img/grimpe/fb03fc3a-51a6-4587-a0f7-f81ec901a1e9.jpg', 4),
(10, '531537d4-bfe5-40c8-93b7-d9746f76e733.jpg', '/img/grimpe/531537d4-bfe5-40c8-93b7-d9746f76e733.jpg', 5),
(11, '3e994f55-4189-4fc6-817b-a72b96226640.jpg', '/img/grimpe/3e994f55-4189-4fc6-817b-a72b96226640.jpg', 5),
(12, '522945ee-037a-4bd2-93a8-91307f355b2a.jpg', '/img/grimpe/522945ee-037a-4bd2-93a8-91307f355b2a.jpg', 6),
(13, '322ea597-d4f2-4a58-ba7f-46a078f1beb0.jpg', '/img/grimpe/322ea597-d4f2-4a58-ba7f-46a078f1beb0.jpg', 7),
(14, '3746f42a-4f61-444a-aa21-ccadb9bdd2ff.jpg', '/img/grimpe/3746f42a-4f61-444a-aa21-ccadb9bdd2ff.jpg', 7),
(15, '957fdb37-b5b6-458c-9aa9-1edbefc82b13.jpg', '/img/grimpe/957fdb37-b5b6-458c-9aa9-1edbefc82b13.jpg', 7),
(16, '6d1ea998-653e-4eb2-bae6-bb0519e2d55b.jpg', '/img/grimpe/6d1ea998-653e-4eb2-bae6-bb0519e2d55b.jpg', 7),
(18, 'ac73dffa-5e77-44be-ace0-06c461b87f40.jpg', '/img/grimpe/ac73dffa-5e77-44be-ace0-06c461b87f40.jpg', 8),
(19, '41c1e6e9-7918-4037-b47b-994aa85b85cf.jpg', '/img/grimpe/41c1e6e9-7918-4037-b47b-994aa85b85cf.jpg', 8),
(21, 'c835dcaf-0f40-4638-a3b2-bc48702752ed.jpg', '/img/grimpe/c835dcaf-0f40-4638-a3b2-bc48702752ed.jpg', 9),
(22, '59328b67-0428-47ac-a0c8-c8ed2643c377.jpg', '/img/grimpe/59328b67-0428-47ac-a0c8-c8ed2643c377.jpg', 9),
(23, '505e357e-b184-4905-9cd5-ad0ed0bea51b.jpg', '/img/grimpe/505e357e-b184-4905-9cd5-ad0ed0bea51b.jpg', 10),
(24, 'bcee952a-e1c5-4c6c-a0d5-a3c283743c19.jpg', '/img/grimpe/bcee952a-e1c5-4c6c-a0d5-a3c283743c19.jpg', 10),
(25, 'd13c1b7a-dc80-485b-9aab-69339718a5d7.jpg', '/img/grimpe/d13c1b7a-dc80-485b-9aab-69339718a5d7.jpg', 11),
(26, '36a18052-2977-4b3a-820a-3a9e29af964b.jpg', '/img/grimpe/36a18052-2977-4b3a-820a-3a9e29af964b.jpg', 11),
(27, '363719af-2e7c-4e70-b905-07e27004c80d.jpg', '/img/grimpe/363719af-2e7c-4e70-b905-07e27004c80d.jpg', 11),
(28, 'b4277b93-3bed-4ef8-9e81-e7daea61bfdf.jpg', '/img/grimpe/b4277b93-3bed-4ef8-9e81-e7daea61bfdf.jpg', 12),
(29, '9b17b770-f077-477d-a6b3-be0c6bea5338.jpg', '/img/grimpe/9b17b770-f077-477d-a6b3-be0c6bea5338.jpg', 12),
(30, '65fd453b-57f6-4f2f-8b30-4af1dfec8085.jpg', '/img/grimpe/65fd453b-57f6-4f2f-8b30-4af1dfec8085.jpg', 13),
(31, 'b8b60287-c72e-4c0f-af1b-c7c2101593cc.jpg', '/img/grimpe/b8b60287-c72e-4c0f-af1b-c7c2101593cc.jpg', 13),
(32, 'b8e9cace-ef7b-4b63-801c-231737877026.jpg', '/img/grimpe/b8e9cace-ef7b-4b63-801c-231737877026.jpg', 13),
(33, 'b046741a-bad2-4afb-95c6-72c1268499ae.jpg', '/img/grimpe/b046741a-bad2-4afb-95c6-72c1268499ae.jpg', 14),
(34, '92e63984-b5ac-4d81-8fe0-0f7dad2c1885.jpg', '/img/grimpe/92e63984-b5ac-4d81-8fe0-0f7dad2c1885.jpg', 14),
(35, 'ce8ee2aa-039e-4ff0-89d5-442f05531813.jpg', '/img/grimpe/ce8ee2aa-039e-4ff0-89d5-442f05531813.jpg', 15),
(36, '282222fb-a84a-4e38-950b-f0ce4c3fec8a.jpg', '/img/grimpe/282222fb-a84a-4e38-950b-f0ce4c3fec8a.jpg', 16),
(37, '9426395b-e95b-4bba-878f-8c457e04d6a8.jpg', '/img/grimpe/9426395b-e95b-4bba-878f-8c457e04d6a8.jpg', 16),
(38, '6a6a7a74-69d5-4112-8f66-23679b335892.jpg', '/img/grimpe/6a6a7a74-69d5-4112-8f66-23679b335892.jpg', 16),
(39, '53e8f282-ddbc-4636-92ba-5fa8b79b3059.jpg', '/img/grimpe/53e8f282-ddbc-4636-92ba-5fa8b79b3059.jpg', 17),
(40, 'a73239b9-5da5-468a-906a-bfcfd5e0b7a1.jpg', '/img/grimpe/a73239b9-5da5-468a-906a-bfcfd5e0b7a1.jpg', 18),
(41, 'fcfded18-983c-43ea-b17f-4879f106a10f.jpg', '/img/grimpe/fcfded18-983c-43ea-b17f-4879f106a10f.jpg', 18),
(42, '2cc0dbeb-222d-4d92-90df-8fbe915f9b8b.jpg', '/img/grimpe/2cc0dbeb-222d-4d92-90df-8fbe915f9b8b.jpg', 19),
(43, '16d835ee-76fa-470a-a812-40a0ae2e22ce.jpg', '/img/grimpe/16d835ee-76fa-470a-a812-40a0ae2e22ce.jpg', 20),
(44, '98f5a417-4aa1-461b-bfa0-2c9670c48206.jpg', '/img/grimpe/98f5a417-4aa1-461b-bfa0-2c9670c48206.jpg', 21),
(46, 'b6427a58-ec9b-4d54-bfe0-66702d44586b.jpg', '/img/grimpe/b6427a58-ec9b-4d54-bfe0-66702d44586b.jpg', 22),
(47, 'd747311b-b51c-47d9-a8bb-9612a38e7249.jpg', '/img/grimpe/d747311b-b51c-47d9-a8bb-9612a38e7249.jpg', 22),
(48, '4b0169d3-1a37-48f3-b76b-57c3902a48ae.jpg', '/img/grimpe/4b0169d3-1a37-48f3-b76b-57c3902a48ae.jpg', 23),
(49, 'fdd3c809-0a5a-41fd-86c3-02907a793c7a.jpg', '/img/grimpe/fdd3c809-0a5a-41fd-86c3-02907a793c7a.jpg', 24),
(50, '593c81d8-5b10-4a02-adfb-0c21a64dbe19.jpg', '/img/grimpe/593c81d8-5b10-4a02-adfb-0c21a64dbe19.jpg', 25),
(51, '848092fa-eade-4a99-8002-a1e7566ae63e.jpg', '/img/grimpe/848092fa-eade-4a99-8002-a1e7566ae63e.jpg', 8),
(52, '16cd4e9b-b588-49e3-bfe6-35c4667ab195.jpg', '/img/grimpe/16cd4e9b-b588-49e3-bfe6-35c4667ab195.jpg', 22),
(53, '40db9099-38dd-4ed7-a00c-df72e0d35045.png', '/img/grimpe/40db9099-38dd-4ed7-a00c-df72e0d35045.png', 10),
(54, '1e939463-21ba-48cd-9c1b-ed3a06b9065a.jpg', '/img/grimpe/1e939463-21ba-48cd-9c1b-ed3a06b9065a.jpg', 10),
(55, '55f96a96-3cd7-4fca-a2eb-7233695231d0.jpg', '/img/grimpe/55f96a96-3cd7-4fca-a2eb-7233695231d0.jpg', 10),
(56, '9d065df8-888c-4c0c-a269-a7e3fa4b33c8.jpg', '/img/grimpe/9d065df8-888c-4c0c-a269-a7e3fa4b33c8.jpg', 25),
(57, '0d1d8375-4315-424a-b476-01f38cb98989.jpg', '/img/grimpe/0d1d8375-4315-424a-b476-01f38cb98989.jpg', 25);

-- --------------------------------------------------------

--
-- Table structure for table `lieux`
--

DROP TABLE IF EXISTS `lieux`;
CREATE TABLE IF NOT EXISTS `lieux` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(50) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `directives` varchar(500) DEFAULT NULL,
  `latitude` decimal(18,15) DEFAULT NULL,
  `longitude` decimal(19,15) DEFAULT NULL,
  `utilisateurId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `titre` (`titre`),
  KEY `utilisateurId` (`utilisateurId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lieux`
--

INSERT INTO `lieux` (`id`, `titre`, `description`, `directives`, `latitude`, `longitude`, `utilisateurId`) VALUES
(1, 'Yosemite National Park, USA', 'La Californie est l\'un des meilleurs États pour l\'escalade, et il n\'y a pratiquement aucune autre zone d\'escalade au monde avec autant d\'histoire que Yosemite. Les grimpeurs l\'appelaient le \"Centre de l\'Univers\". En effet, ils avaient raison. Pendant des générations, les meilleurs grimpeurs du monde ont élu domicile au légendaire Camp 4. Ils se feraient appeler \"The Stone Monkeys\" et passeraient leurs journées à grimper ou à planifier leur prochain exploit d\'escalade.', '(Conseil : avant de réserver un voyage, faites vos devoirs et regardez Valley Uprising). Yosemite a toujours été à l\'avant-garde du monde de l\'escalade et peu de choses ont changé aujourd\'hui, à l\'exception de la réglementation. Si vous envisagez de devenir le prochain Stone Monkey of Yosemite (et qui peut vous en vouloir !), vous aurez du mal à convaincre les rangers du parc que Camp 4 est votre nouvelle adresse.', '37.897509537530950', '-119.526540887511760', 1),
(2, 'Kalymnos, Greece', 'Y a-t-il quelque chose de mieux qu\'un porte-à-faux parfait, parsemé de tufs magnifiquement sculptés, cachant toutes sortes de trucs d\'escalade sportive, comme les barres de genou, les genoux profonds, les crochets de talon et les crochets d\'orteil ? Si vous partagez ma vision d\'une voie d\'escalade sportive parfaite, Kalymnos est le « X » sur votre carte au trésor. Si vous ne partagez pas ma vision, grimpez-y quand même ! La région regorge de trésors d\'escalade cachés.', 'de tricherie d\'escalade sportive, comme les barres de genou, les genoux à chute profonde, les crochets de talon et les crochets d\'orteil ? Si vous partagez ma vision d\'une voie d\'escalade sportive parfaite, Kalymnos est le « X » sur votre carte au trésor. Si vous ne partagez pas ma vision, grimpez-y quand même ! La région regorge de trésors d\'escalade cachés. Les méga terrains en surplomb pompeux de Kalymnos sont le plat principal de l\'île, et ses plus de 3 400 voies, allant des dalles aux toit.', '37.071977184099250', '27.082741282175693', 1),
(3, 'Dolomites, Italy', 'Comment cela sonne-t-il ? Vous vous levez avant l\'aube (l\'excitation ne vous laisse pas dormir de toute façon), vous forcez le petit-déjeuner, marchez pendant deux heures jusqu\'au pied du mur, grimpez pas après pas de rocher fragmentaire tout en taillant d\'anciens pitons rouillés. Vous gèlez au relais tandis que votre partenaire met une éternité à trouver le prochain ancrage. Tu cours contre la lumière déclinante', 'pour inévitablement perdre et finir par descendre bien avant dans la nuit. Cela ne semble pas amusant? Croyez-le ou non, il y a beaucoup d\'alpinistes qui s\'inscriraient pour une aventure alpine comme celle-ci n\'importe quand !', '46.412217869542680', '11.844549569363380', 3),
(4, 'Fontainebleau, France', 'Quand je suis entré pour la première fois dans la forêt de Fontainebleau, à seulement 90 km au sud de Paris, je me suis senti comme un gamin le matin de Noël ! J\'ai été stupéfait par tous les rochers de grès parfaitement lisses, leurs formes incroyables, leurs couleurs et leur texture folle de «peau d\'éléphant». Je n\'arrêtais pas de me demander comment la nature avait pu créer cet endroit ? La meilleure conclusion que je pouvais présumer était que la pierre était là pour un but : elle était', 'Depuis la fin du XIXe siècle, les alpinistes parisiens gravissaient successivement les problèmes de bloc de Font (c\'est-à-dire ce que nous appelons aujourd\'hui les circuits de bloc) pour se préparer à de plus grands murs qu\'ils avaient l\'intention de gravir lors de futures expéditions. Ce passe-temps a ensuite décollé de lui-même, évoluant vers ce que nous appelons aujourd\'hui le \"bouldering\" - sans doute la discipline la plus populaire de l\'escalade. Même l\'échelle de notatio', '48.470540598405580', '2.721071397314132', 2),
(5, 'Squamish, Canada', 'Si je devais décrire Squamish en quelques mots, je dirais : l\'aventure à votre porte. À seulement une heure au nord de Vancouver, il a tout ce dont un aventurier en plein air a besoin, y compris du granit qui fera pleurer de joie les fans d\'escalade de Front Range. Il y a de grands murs intimidants, un terrain simple et de bloc de classe mondiale, avec de l\'escalade traditionnelle et sportive.', 'Peu d\'endroits ont autant d\'itinéraires de classe mondiale entre les niveaux et les disciplines d\'escalade. À cause de cela et de la facilité d\'accès à tant de rochers, je trouve que Squamish est un endroit vraiment unique. L\'escalade ici se fait sur le granit lisse le plus fin, ce qui signifie de nombreuses fissures de séparation. Il existe des lignes de fissures classiques de tous les grades - de 5,8 à 5,14. Si vous n\'avez pas d\'expérience préalable dans l\'escalade de fissures.', '49.709961733303590', '-123.155973557108960', 2),
(6, 'Zermatt, Switzerland', 'Dans les Alpes suisses, juste à côté de la frontière italienne, se trouve Zermatt, l\'une des villes alpines les plus célèbres d\'Europe. Qu\'est-ce qui le rend si génial ? La réponse est simple : il donne accès à 38 sommets de 13,00 pieds. Zermatt est sans conteste l\'un des meilleurs endroits pour les grimpeurs qui n\'ont pas peur des crampons et des piolets. Certes, je ne fais pas partie de ce groupe, mais j\'ai une grande admiration pour cette race de grimpeur. Le paysage autour de Zermatt.', 'Escalader à Zermatt ne consiste pas seulement à escalader des parois rocheuses, c\'est une aventure alpine complète impliquant la traversée de glaciers, des altitudes élevées et une logistique complexe. Une connaissance de base des techniques d\'escalade alpine est indispensable, même pour les voies les plus faciles. Quand on parle d\'escalade autour de Zermatt, il y a un sommet qui vole toute la vedette. C\'est le majestueux Cervin, qui se dresse à près de 15 000 pieds au-dessus de la ville.', '46.097939619429360', '7.755522329815334', 6),
(7, 'Red Rock, USA', 'C\'est presque absurde la polarité entre la fourmilière humaine brillante de Las Vegas et la nature sauvage de la zone de conservation nationale de Red Rock (alias Red Rocks). Dans le premier, vous trouverez des néons clignotants et des divertissements 24h/24 ; à seulement 20 miles, vous trouverez la sérénité parmi les rochers et l\'escalade pour tous les types.', 'C\'est presque absurde la polarité entre la fourmilière humaine brillante de Las Vegas et la nature sauvage de la zone de conservation nationale de Red Rock (alias Red Rocks). Dans le premier, vous trouverez des néons clignotants et des divertissements 24h/24 ; à seulement 20 miles, vous trouverez la sérénité parmi les rochers et l\'escalade pour tous les types.', '39.666495795034210', '-105.205383297389740', 2),
(8, 'Rocklands, South Africa', 'Rocklands est une zone de bloc à trois heures au nord de la plus ancienne ville sud-africaine, Cape Town. Des kilomètres et des kilomètres de rochers de grès rouge et orange parfaits sont répartis dans le désert de la région sauvage de Cederberg.', 'L\'histoire d\'amour entre les grimpeurs et Yosemite n\'est bien sûr pas sans raison. Les grimpeurs adorent le rock, et Yosemite offre une mer de granit incroyable, avec du souffle...', '-34.060984612574170', '18.614880579568162', 2);

-- --------------------------------------------------------

--
-- Table structure for table `utilisateurs`
--

DROP TABLE IF EXISTS `utilisateurs`;
CREATE TABLE IF NOT EXISTS `utilisateurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) DEFAULT NULL,
  `courriel` varchar(255) DEFAULT NULL,
  `mdp` varchar(255) DEFAULT NULL,
  `estAdmin` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `courriel` (`courriel`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `nom`, `courriel`, `mdp`, `estAdmin`) VALUES
(1, 'A asp', 'a@asp.ca', '$2b$10$lTms3.6Y4KixDw8R74/rH.sEg3xCi6CRWosjl7aCCbzsl8/5Tc3xe', 0),
(2, 'B asp', 'b@asp.ca', '$2b$10$62iYK2BbAhVfTGFgsJtZiOsYXBT9eFTqYp5S6Yj6gOu9HA9y7aF9e', 0),
(3, 'C asp', 'c@asp.ca', '$2b$10$zmJce2FoLm56ga3C6ntpdOhKx3oSumGVSg2gskm7RZ.dBqoUd6vOe', 0),
(4, 'D asp', 'd@asp.ca', '$2b$10$Loi0IvZl9DvDfnFKL39l6eOrjBuCgFqiK/zGlhtz.Cf2X2AAS7rfK', 0),
(5, 'E asp', 'e@asp.ca', '$2b$10$9cnDzjzxwX.B/xQF6pIcwujjCsk3zb/7f7vQNvmTgbVKBkrdR6sCm', 0),
(6, 'Admin', 'admin@asp.ca', '$2b$10$1H7qM1EzwnQeokv/Vvm5y.5276aW8rI4yahqPeQ5JdGnZEQvMGZiC', 1);

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

DROP TABLE IF EXISTS `votes`;
CREATE TABLE IF NOT EXISTS `votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nbEtoiles` decimal(10,2) DEFAULT 1.00,
  `grimpeId` int(11) DEFAULT NULL,
  `utilisateurId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `grimpeId` (`grimpeId`),
  KEY `utilisateurId` (`utilisateurId`)
) ENGINE=InnoDB AUTO_INCREMENT=397 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`id`, `nbEtoiles`, `grimpeId`, `utilisateurId`) VALUES
(1, '2.00', 25, 6),
(2, '5.00', 25, 6),
(3, '2.00', 25, 6),
(4, '3.00', 25, 6),
(5, '4.00', 25, 6),
(6, '3.00', 25, 6),
(7, '4.00', 25, 6),
(8, '2.00', 25, 6),
(9, '5.00', 25, 6),
(10, '5.00', 25, 6),
(11, '1.00', 25, 6),
(12, '2.00', 25, 6),
(13, '4.00', 20, 6),
(14, '2.00', 20, 6),
(15, '2.00', 20, 6),
(16, '1.00', 20, 6),
(17, '1.00', 20, 6),
(18, '5.00', 20, 6),
(19, '4.00', 20, 6),
(20, '1.00', 20, 6),
(21, '3.00', 20, 6),
(22, '1.00', 20, 6),
(23, '2.00', 1, 6),
(24, '3.00', 1, 6),
(25, '1.00', 1, 6),
(26, '3.00', 1, 6),
(27, '4.00', 1, 6),
(28, '1.00', 1, 6),
(29, '3.00', 1, 6),
(30, '1.00', 1, 6),
(31, '3.00', 1, 6),
(32, '3.00', 1, 6),
(33, '1.00', 1, 6),
(34, '5.00', 24, 6),
(35, '4.00', 24, 6),
(36, '5.00', 24, 6),
(37, '5.00', 24, 6),
(38, '3.00', 24, 6),
(39, '4.00', 24, 6),
(40, '2.00', 24, 6),
(41, '2.00', 24, 6),
(42, '4.00', 24, 6),
(43, '5.00', 8, 6),
(44, '4.00', 8, 6),
(45, '2.00', 8, 6),
(46, '3.00', 8, 6),
(47, '1.00', 8, 6),
(48, '2.00', 6, 6),
(49, '1.00', 6, 6),
(50, '3.00', 6, 6),
(51, '4.00', 6, 6),
(52, '2.00', 6, 6),
(53, '1.00', 4, 6),
(54, '1.00', 4, 6),
(55, '1.00', 4, 6),
(56, '1.00', 4, 6),
(57, '1.00', 4, 6),
(58, '2.00', 4, 6),
(59, '2.00', 4, 6),
(60, '5.00', 22, 6),
(61, '5.00', 22, 6),
(62, '5.00', 22, 6),
(63, '5.00', 22, 6),
(64, '3.00', 22, 6),
(65, '4.00', 22, 6),
(66, '3.00', 22, 6),
(67, '3.00', 22, 6),
(68, '3.00', 22, 6),
(69, '1.00', 22, 6),
(70, '1.00', 11, 6),
(71, '5.00', 11, 6),
(72, '5.00', 23, 6),
(73, '5.00', 23, 6),
(74, '5.00', 23, 6),
(75, '5.00', 23, 6),
(76, '3.00', 23, 6),
(77, '4.00', 23, 6),
(78, '5.00', 23, 6),
(79, '5.00', 23, 6),
(80, '3.00', 23, 6),
(81, '4.00', 23, 6),
(82, '2.00', 23, 6),
(83, '5.00', 23, 6),
(84, '4.00', 23, 6),
(85, '1.00', 21, 6),
(86, '2.00', 19, 5),
(87, '3.00', 19, 5),
(88, '1.00', 19, 5),
(89, '3.00', 19, 5),
(90, '4.00', 19, 5),
(91, '5.00', 15, 5),
(92, '5.00', 15, 5),
(93, '5.00', 15, 5),
(94, '4.00', 15, 5),
(95, '3.00', 15, 5),
(96, '4.00', 15, 5),
(97, '5.00', 15, 5),
(98, '3.00', 15, 5),
(99, '2.00', 15, 5),
(100, '3.00', 15, 5),
(101, '3.00', 5, 5),
(102, '4.00', 5, 5),
(103, '3.00', 5, 5),
(104, '5.00', 5, 5),
(105, '4.00', 5, 5),
(106, '4.00', 5, 5),
(107, '3.00', 5, 5),
(108, '5.00', 10, 5),
(109, '5.00', 10, 5),
(110, '5.00', 10, 5),
(111, '5.00', 10, 5),
(112, '5.00', 10, 5),
(113, '5.00', 10, 5),
(114, '5.00', 10, 5),
(115, '1.00', 2, 4),
(116, '2.00', 2, 4),
(117, '3.00', 2, 4),
(118, '2.00', 2, 4),
(119, '2.00', 2, 4),
(120, '2.00', 2, 4),
(121, '2.00', 2, 4),
(122, '3.00', 13, 4),
(123, '5.00', 13, 4),
(124, '5.00', 13, 4),
(125, '5.00', 13, 4),
(126, '5.00', 13, 4),
(127, '5.00', 13, 4),
(128, '4.00', 13, 4),
(129, '3.00', 13, 4),
(130, '4.00', 13, 4),
(131, '4.00', 13, 4),
(132, '4.00', 12, 4),
(133, '3.00', 12, 4),
(134, '2.00', 12, 4),
(135, '1.00', 12, 4),
(136, '5.00', 12, 4),
(137, '4.00', 12, 4),
(138, '3.00', 12, 4),
(139, '3.00', 16, 4),
(140, '2.00', 16, 4),
(141, '5.00', 16, 4),
(142, '3.00', 21, 4),
(143, '4.00', 21, 4),
(144, '2.00', 21, 4),
(145, '5.00', 21, 4),
(146, '3.00', 21, 4),
(147, '5.00', 21, 4),
(148, '5.00', 17, 4),
(149, '4.00', 17, 4),
(150, '3.00', 17, 4),
(151, '3.00', 7, 2),
(152, '4.00', 7, 2),
(153, '2.00', 7, 2),
(154, '5.00', 7, 2),
(155, '1.00', 7, 2),
(156, '3.00', 7, 2),
(157, '3.00', 7, 2),
(158, '4.00', 14, 2),
(159, '1.00', 14, 2),
(160, '3.00', 14, 2),
(161, '4.00', 14, 2),
(162, '5.00', 14, 2),
(163, '5.00', 14, 2),
(164, '3.00', 14, 2),
(165, '5.00', 14, 2),
(166, '4.00', 18, 2),
(167, '3.00', 18, 2),
(168, '2.00', 18, 2),
(169, '3.00', 18, 2),
(170, '5.00', 10, 2),
(171, '5.00', 10, 2),
(172, '5.00', 10, 2),
(173, '5.00', 22, 2),
(174, '5.00', 22, 2),
(175, '4.00', 21, 2),
(176, '5.00', 10, 1),
(177, '5.00', 10, 1),
(178, '5.00', 10, 1),
(179, '5.00', 10, 1),
(180, '5.00', 10, 1),
(181, '5.00', 10, 1),
(182, '5.00', 10, 1),
(183, '5.00', 10, 1),
(184, '5.00', 10, 1),
(185, '5.00', 10, 1),
(186, '5.00', 10, 1),
(187, '5.00', 10, 1),
(188, '5.00', 10, 1),
(189, '5.00', 10, 1),
(190, '5.00', 10, 1),
(191, '5.00', 23, 1),
(192, '5.00', 23, 1),
(193, '5.00', 23, 1),
(194, '5.00', 23, 1),
(195, '5.00', 23, 1),
(196, '5.00', 23, 1),
(197, '5.00', 23, 1),
(198, '5.00', 23, 1),
(199, '5.00', 23, 1),
(200, '5.00', 23, 1),
(201, '5.00', 23, 1),
(202, '5.00', 23, 1),
(203, '5.00', 23, 1),
(204, '5.00', 23, 1),
(205, '5.00', 23, 1),
(206, '5.00', 23, 1),
(207, '5.00', 23, 1),
(208, '5.00', 23, 1),
(209, '5.00', 23, 1),
(210, '5.00', 23, 1),
(211, '5.00', 23, 1),
(212, '5.00', 23, 1),
(213, '5.00', 23, 1),
(214, '5.00', 23, 1),
(215, '5.00', 23, 1),
(216, '5.00', 23, 1),
(217, '5.00', 23, 1),
(218, '5.00', 23, 1),
(219, '5.00', 23, 1),
(220, '5.00', 23, 1),
(221, '5.00', 23, 1),
(222, '5.00', 23, 1),
(223, '5.00', 23, 1),
(224, '5.00', 13, 1),
(225, '5.00', 13, 1),
(226, '5.00', 13, 1),
(227, '5.00', 13, 1),
(228, '5.00', 13, 1),
(229, '5.00', 13, 1),
(230, '5.00', 13, 1),
(231, '5.00', 13, 1),
(232, '5.00', 13, 1),
(233, '5.00', 13, 1),
(234, '5.00', 13, 1),
(235, '5.00', 13, 1),
(236, '5.00', 13, 1),
(237, '5.00', 13, 1),
(238, '5.00', 13, 1),
(239, '5.00', 13, 1),
(240, '5.00', 13, 1),
(241, '5.00', 13, 1),
(242, '5.00', 17, 1),
(243, '5.00', 17, 1),
(244, '5.00', 17, 1),
(245, '5.00', 17, 1),
(246, '5.00', 17, 1),
(247, '3.00', 17, 1),
(248, '3.00', 17, 1),
(249, '3.00', 17, 1),
(250, '3.00', 17, 1),
(251, '5.00', 17, 1),
(252, '5.00', 17, 1),
(253, '5.00', 17, 1),
(254, '5.00', 17, 1),
(255, '5.00', 17, 1),
(256, '5.00', 17, 1),
(257, '4.00', 17, 1),
(258, '4.00', 17, 1),
(259, '5.00', 17, 1),
(260, '5.00', 17, 1),
(261, '5.00', 17, 1),
(262, '5.00', 17, 1),
(263, '5.00', 17, 1),
(264, '5.00', 17, 1),
(265, '5.00', 17, 1),
(266, '5.00', 17, 1),
(267, '5.00', 17, 1),
(268, '5.00', 17, 1),
(269, '5.00', 17, 1),
(270, '5.00', 17, 1),
(271, '5.00', 17, 1),
(272, '5.00', 17, 1),
(273, '5.00', 17, 1),
(274, '5.00', 17, 1),
(275, '5.00', 17, 1),
(276, '5.00', 17, 1),
(277, '5.00', 17, 1),
(278, '5.00', 17, 1),
(279, '5.00', 17, 1),
(280, '5.00', 17, 1),
(281, '5.00', 17, 1),
(282, '5.00', 17, 1),
(283, '5.00', 17, 1),
(284, '5.00', 22, 1),
(285, '5.00', 22, 1),
(286, '5.00', 22, 1),
(287, '5.00', 22, 1),
(288, '5.00', 22, 1),
(289, '5.00', 22, 1),
(290, '5.00', 22, 1),
(291, '5.00', 22, 1),
(292, '5.00', 22, 1),
(293, '5.00', 22, 1),
(294, '5.00', 22, 1),
(295, '5.00', 22, 1),
(296, '5.00', 22, 1),
(297, '5.00', 22, 1),
(298, '5.00', 22, 1),
(299, '5.00', 22, 1),
(300, '5.00', 22, 1),
(301, '5.00', 22, 1),
(302, '5.00', 22, 1),
(303, '5.00', 22, 1),
(304, '4.00', 22, 1),
(305, '4.00', 22, 1),
(306, '5.00', 22, 1),
(307, '5.00', 22, 1),
(308, '5.00', 22, 1),
(309, '5.00', 22, 1),
(310, '5.00', 22, 1),
(311, '5.00', 22, 1),
(312, '5.00', 22, 1),
(313, '5.00', 22, 1),
(314, '5.00', 22, 1),
(315, '5.00', 22, 1),
(316, '5.00', 22, 1),
(317, '5.00', 15, 1),
(318, '5.00', 15, 1),
(319, '5.00', 15, 1),
(320, '5.00', 15, 1),
(321, '5.00', 15, 1),
(322, '5.00', 15, 1),
(323, '5.00', 15, 1),
(324, '5.00', 15, 1),
(325, '5.00', 15, 1),
(326, '5.00', 15, 1),
(327, '4.00', 15, 1),
(328, '5.00', 15, 1),
(329, '5.00', 15, 1),
(330, '5.00', 15, 1),
(331, '5.00', 15, 1),
(332, '5.00', 15, 1),
(333, '5.00', 15, 1),
(334, '5.00', 15, 1),
(335, '5.00', 15, 1),
(336, '5.00', 15, 1),
(337, '5.00', 15, 1),
(338, '5.00', 15, 1),
(339, '5.00', 15, 1),
(340, '5.00', 15, 1),
(341, '5.00', 15, 1),
(342, '5.00', 15, 1),
(343, '5.00', 24, 1),
(344, '5.00', 24, 1),
(345, '5.00', 24, 1),
(346, '5.00', 24, 1),
(347, '5.00', 24, 1),
(348, '5.00', 24, 1),
(349, '5.00', 24, 1),
(350, '5.00', 24, 1),
(351, '5.00', 24, 1),
(352, '5.00', 24, 1),
(353, '5.00', 24, 1),
(354, '5.00', 24, 1),
(355, '5.00', 24, 1),
(356, '5.00', 24, 1),
(357, '5.00', 24, 1),
(358, '4.00', 24, 1),
(359, '5.00', 24, 1),
(360, '5.00', 24, 1),
(361, '5.00', 24, 1),
(362, '5.00', 24, 1),
(363, '5.00', 24, 1),
(364, '5.00', 24, 1),
(365, '5.00', 24, 1),
(366, '5.00', 24, 1),
(367, '5.00', 24, 1),
(368, '5.00', 24, 1),
(369, '5.00', 24, 1),
(370, '4.00', 14, 1),
(371, '4.00', 14, 1),
(372, '4.00', 14, 1),
(373, '4.00', 14, 1),
(374, '4.00', 14, 1),
(375, '4.00', 14, 1),
(376, '4.00', 14, 1),
(377, '4.00', 14, 1),
(378, '4.00', 14, 1),
(379, '4.00', 14, 1),
(380, '4.00', 14, 1),
(381, '4.00', 14, 1),
(382, '4.00', 14, 1),
(383, '4.00', 14, 1),
(384, '4.00', 14, 1),
(385, '4.00', 14, 1),
(386, '4.00', 14, 1),
(387, '5.00', 14, 1),
(388, '5.00', 14, 1),
(389, '5.00', 21, 1),
(390, '5.00', 21, 1),
(391, '5.00', 21, 1),
(392, '5.00', 21, 1),
(393, '5.00', 21, 1),
(394, '5.00', 21, 1),
(395, '5.00', 21, 1),
(396, '5.00', 21, 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `grimpes`
--
ALTER TABLE `grimpes`
  ADD CONSTRAINT `grimpes_ibfk_1` FOREIGN KEY (`utilisateurId`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `grimpes_ibfk_2` FOREIGN KEY (`lieuxId`) REFERENCES `lieux` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `images_ibfk_1` FOREIGN KEY (`grimpeId`) REFERENCES `grimpes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lieux`
--
ALTER TABLE `lieux`
  ADD CONSTRAINT `lieux_ibfk_1` FOREIGN KEY (`utilisateurId`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `votes`
--
ALTER TABLE `votes`
  ADD CONSTRAINT `votes_ibfk_1` FOREIGN KEY (`grimpeId`) REFERENCES `grimpes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `votes_ibfk_2` FOREIGN KEY (`utilisateurId`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
